Readme for OpenTitus Blues viewer

OpenTitus Blues viewer is released under the Gnu GPL version 3 or (at your option) any later version of the license, and it is released "as is"; without any warranty.

Author:
Eirik Stople

Thanks to:
Titus Interactive who made the great game Blues Brothers!
Jesses, various information!
Frenkel, for information found at http://www.shikadi.net/moddingwiki/The_Blues_Brothers



The original game Blues Brothers was made by the company Titus Interactive.



You need the original game files to make use of these applications. These applications parses the original files. They have only been tested on a Windows-based environment yet.
You need SDL to compile. To compile, use the following commands:

All (linux):
make

All (windows):
make -f Makefile_win


To run the level viewer, run
./levelviewer.exe
Or simply launch levelviewer.exe


To use the UnSQZ program, run
./unsqz <SQZ file>
This will extract the file to "output.lvl".


Use:
Arrows: Navigate the window
Page up/page down: switch level/image
L: View levels (tiles only)
I: View images (tiles/intro/player selection/insert disc)
O: Overlay tiles
E: Enemy sprites
S: Player sprites



The levelviewer (and later also the game) is configured by a file in the same directory; "blues.conf". This file is parsed line by line, and lines starting with # will be skipped.
NB: The editor is quite strict on the blues.conf file! If the levelviewer fail to start, check stdout.txt!
Keywords:
reswidth = Number of pixels wide, default 320 (originally 640, but the "pixels" in the original game was two pixels wide, so 320 should give the correct size)
resheight = Number of pixels height, default 240 (originally 480, 240 should give the correct size)
bitdepth = Number of bits pr. pixel, default 32 (the game data files have a 16 colour palette, which means 4 bpp, but higher bpp will work as well)
videomode = Video mode; 0 is window mode and 1 is fullscreen, default 0
levelcount = Number of levels, default 6
level 1-6 = Location of the level file for all levels
imagecount = Number of images, default 6
imagecount 1-6 = Location of the image file for all images
