Readme for UnSQZ

UnSQZ is released under the Gnu GPL version 3 or (at your option) any later version of the license, and it is released "as is"; without any warranty.
Source code is available in OpenTitus 0.3.0.

Downloads: opentitus.sourceforge.net


Author:
Eirik Stople

Thanks to:
Titus Interactive who made many great games!
Jesses, various information!


UnSQZ is a tool for uncompressing SQZ-compressed files. Such files are present in Titus the Fox, Moktar and Blues Brothers, games made by Titus Interactive.
SQZ files are compressed files, that can use either Huffman or LZW compression.
The SQZ file format is described here http://ttf.mine.nu/techdocs.htm
For more information, check out http://www.shikadi.net/moddingwiki/Titus_the_Fox


Usage:
unsqz.exe inputfile

UnSQZ outputs the extracted data to "output.lvl".